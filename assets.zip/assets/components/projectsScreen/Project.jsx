import React, { useState, useEffect } from "react";
import { View, Text, TouchableOpacity, Button, TextInput } from "react-native";
import styles from "../../styles/styleActiveInactive";
import Modal from "react-native-modal";
import { Icon } from "react-native-elements";
import CrearTarea from "./modals/CreateTask";
import EditarProyecto from "./modals/EditProject";
import Tarea from "./Task";
import Compartir from "./modals/Share";
import CustomAlertModal from "../Alerts";
import { useModalFunctions } from "../Functions-Alerts";
import axios from 'axios';

const Proyecto = () => {
    const projectApiUrl = 'http://10.0.2.2:3000/api/projects/651cccab83d3b36421c2a7bb'; // Cambia la URL de la API según tus necesidades
    const {
        errorModalVisible, infoModalVisible, successModalVisible, questionModalVisible,
        showErrorAlert, showInfoAlert, showSuccessAlert, showQuestionAlert,
        closeErrorAlert, closeInfoAlert, closeSuccessAlert, closeQuestionAlert,
    } = useModalFunctions();

    const [activeState, setActiveState] = useState({
        activo1: false,
    });

    const toggleAccordion = (projectName) => {
        setActiveState({
            ...activeState,
            [projectName]: !activeState[projectName],
        });
    };

    const [modalOpciones, setModalOpciones] = useState(false);
    const mostrarMOpciones = () => {
        setModalOpciones(!modalOpciones);
    };

    const [projectTitle, setProjectTitle] = useState(""); // Estado para almacenar el título del proyecto

    useEffect(() => {
        // Realizar una solicitud GET a la API al cargar el componente
        axios.get(projectApiUrl)
            .then(response => {
                // Obtiene el título del proyecto desde la respuesta de la API
                const tituloProyecto = response.data; // Asegúrate de que la estructura de tu respuesta sea correcta

                // Actualiza el estado con el título del proyecto
                setProjectTitle(tituloProyecto);
            })
            .catch(error => {
                // Maneja errores de solicitud aquí
                console.error(error);
            });
    }, []); // El segundo argumento vacío asegura que la solicitud se realice solo una vez

    return (
        <View style={styles.item}>
            <TouchableOpacity onPress={() => toggleAccordion("activo1")}>
                <View style={styles.flexRow}>
                    <View style={[styles.activosTareas, styles.colorAP]}>
                        <Text
                            style={{
                                color: "white",
                                fontWeight: "bold",
                                padding: 10,
                                fontSize: 17,
                            }}
                        >
                            {projectTitle} {/* Muestra el título del proyecto */}
                        </Text>
                        <View style={styles.optionesTareasAct}>
                            <Icon
                                name={activeState.activo1 ? "chevron-up" : "chevron-down"}
                                type="font-awesome"
                                color={"white"}
                                style={{ marginRight: 10 }}
                            />
                            <Button title="=" onPress={mostrarMOpciones} />
                        </View>
                    </View>
                </View>
                <Modal
                    isVisible={modalOpciones}
                    animationIn="slideInUp"
                    animationOut="slideOutDown"
                    backdropOpacity={0.5}
                    onBackdropPress={mostrarMOpciones}
                    style={{
                        justifyContent: "center",
                        alignItems: "center",
                        margin: 0,
                    }}
                >
                    <View style={styles.modalOpciones}>
                        <EditarProyecto />
                        <CrearTarea />
                        <Compartir />
                        <TouchableOpacity
                            style={{
                                display: "flex",
                                flexDirection: "row",
                                justifyContent: "start",
                                alignItems: "center",
                                border: "2px solid red",
                            }}
                            onPress={showQuestionAlert}
                        >
                            <Icon
                                name="delete"
                                size={20}
                                style={{ marginRight: 10 }}
                                color="black"
                            />
                            <Text>Eliminar Proyecto</Text>
                        </TouchableOpacity>
                        <CustomAlertModal
                            isVisible={questionModalVisible}
                            type="question"
                            message="¿Estás seguro?"
                            onClose={closeQuestionAlert}
                        />
                        <TouchableOpacity
                            style={{
                                display: "flex",
                                flexDirection: "row",
                                justifyContent: "start",
                                alignItems: "center",
                                border: "2px solid red",
                            }}
                            onPress={showInfoAlert}
                        >
                            <Icon
                                name="check"
                                size={20}
                                style={{ marginRight: 10 }}
                                color="black"
                            />
                            <Text>Terminar Proyecto</Text>
                        </TouchableOpacity>
                        <CustomAlertModal
                            isVisible={infoModalVisible}
                            type="info"
                            message="El proyecto se terminara definitivamente"
                            onClose={closeInfoAlert}
                        />
                    </View>
                </Modal>
            </TouchableOpacity>

            {activeState.activo1 && (
                <View style={styles.contenido}>
                    <View style={styles.contDescripcion}>
                        <Text style={styles.h3}>Descripción</Text>
                        <Text style={styles.p}>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                            Ducimus quos commodi neque quod dicta mollitia facere ipsa
                            fuga natus perferendis corporis doloremque veritatis, iure
                            reiciendis eius eveniet doloribus, beatae soluta!
                        </Text>
                    </View>
                    <View style={styles.conTareas}>
                        <Text style={styles.h3}>Por Hacer</Text>
                        <Tarea />
                        <Tarea />
                        <Tarea />
                    </View>
                    <View style={styles.conTareas}>
                        <Text style={styles.h3}>En proceso</Text>
                        <Tarea />
                    </View>
                    <View style={styles.conTareas}>
                        <Text style={styles.h3}>Hecho</Text>
                        <Tarea />
                    </View>
                </View>
            )}
        </View>
    );
}

export default Proyecto;