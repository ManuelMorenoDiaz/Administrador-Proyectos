import React from 'react';
import { SafeAreaView, StyleSheet, View, Text } from 'react-native';
import { Calendar } from 'react-native-calendars';

const CalendarCalendar=()=>{
    
}